const mongoose = require("mongoose");

const carSchema = new mongoose.Schema({
  name:         { type: String, required: true, trim: true },
  brand:        { type: String, required: true, trim: true },
  category:     { type: String, enum: ["Sedan", "SUV", "Hatchback", "Luxury", "Electric", "Van"], required: true },
  pricePerDay:  { type: Number, required: true },
  fuelType:     { type: String, enum: ["Petrol", "Diesel", "Electric", "Hybrid"], required: true },
  transmission: { type: String, enum: ["Manual", "Automatic"], required: true },
  seats:        { type: Number, required: true },
  image:        { type: String, default: "" },   // URL or filename
  description:  { type: String, default: "" },
  features:     [{ type: String }],
  isAvailable:  { type: Boolean, default: true },
  rating:       { type: Number, default: 4.0 },
  location:     { type: String, default: "Delhi, India" },
}, { timestamps: true });

module.exports = mongoose.model("Car", carSchema);
