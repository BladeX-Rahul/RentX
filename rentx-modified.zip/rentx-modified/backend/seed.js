require("dotenv").config();
const mongoose = require("mongoose");
const User = require("./models/User");
const Car  = require("./models/Car");

const cars = [
  { name: "City", brand: "Honda", category: "Sedan", pricePerDay: 1800, fuelType: "Petrol", transmission: "Manual", seats: 5, rating: 4.5, description: "Comfortable and fuel-efficient city sedan.", features: ["AC", "Bluetooth", "Power Windows", "Airbags"], image: "https://placehold.co/600x380/4741D4/white?text=Honda+City", location: "Delhi, India" },
  { name: "Creta", brand: "Hyundai", category: "SUV", pricePerDay: 2800, fuelType: "Diesel", transmission: "Automatic", seats: 5, rating: 4.7, description: "Feature-packed SUV perfect for long drives.", features: ["Sunroof", "360 Camera", "Cruise Control", "6 Airbags"], image: "https://placehold.co/600x380/22c55e/white?text=Hyundai+Creta", location: "Mumbai, India" },
  { name: "Swift", brand: "Maruti", category: "Hatchback", pricePerDay: 1200, fuelType: "Petrol", transmission: "Manual", seats: 5, rating: 4.3, description: "Sporty hatchback ideal for city commutes.", features: ["AC", "Music System", "Power Steering"], image: "https://placehold.co/600x380/f59e0b/white?text=Maruti+Swift", location: "Bangalore, India" },
  { name: "Fortuner", brand: "Toyota", category: "SUV", pricePerDay: 4500, fuelType: "Diesel", transmission: "Automatic", seats: 7, rating: 4.8, description: "Premium 7-seater SUV for family and adventure trips.", features: ["4WD", "Sunroof", "Leather Seats", "9 Airbags", "ADAS"], image: "https://placehold.co/600x380/ef4444/white?text=Toyota+Fortuner", location: "Delhi, India" },
  { name: "Nexon EV", brand: "Tata", category: "Electric", pricePerDay: 2200, fuelType: "Electric", transmission: "Automatic", seats: 5, rating: 4.6, description: "Award-winning electric SUV with impressive range.", features: ["350km Range", "Fast Charging", "Sunroof", "Connected Car Tech"], image: "https://placehold.co/600x380/6366f1/white?text=Tata+Nexon+EV", location: "Pune, India" },
  { name: "Innova Crysta", brand: "Toyota", category: "Van", pricePerDay: 3200, fuelType: "Diesel", transmission: "Manual", seats: 7, rating: 4.6, description: "The most trusted MPV for family and group travel.", features: ["Captain Seats", "Rear AC", "USB Charging", "7 Airbags"], image: "https://placehold.co/600x380/8b5cf6/white?text=Toyota+Innova", location: "Chennai, India" },
  { name: "Venue", brand: "Hyundai", category: "SUV", pricePerDay: 1900, fuelType: "Petrol", transmission: "Automatic", seats: 5, rating: 4.4, description: "Connected compact SUV with smart features.", features: ["Sunroof", "BlueLink Connected", "Wireless Charger"], image: "https://placehold.co/600x380/14b8a6/white?text=Hyundai+Venue", location: "Hyderabad, India" },
  { name: "Baleno", brand: "Maruti", category: "Hatchback", pricePerDay: 1400, fuelType: "Petrol", transmission: "Automatic", seats: 5, rating: 4.2, description: "Premium hatchback with spacious interiors.", features: ["Heads-up Display", "360 Camera", "Wireless Charging"], image: "https://placehold.co/600x380/f97316/white?text=Maruti+Baleno", location: "Kolkata, India" },
];

async function seed() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log("Connected to MongoDB");

  // Clear existing
  await Car.deleteMany();
  await User.deleteMany({ role: "admin" });

  // Create admin
  await User.create({
    name: "Admin",
    email: "admin@rentx.com",
    password: "admin123",
    role: "admin",
  });

  // Create cars
  await Car.insertMany(cars);

  console.log("✅ Seeded: 8 cars + 1 admin user");
  console.log("   Admin email:    admin@rentx.com");
  console.log("   Admin password: admin123");
  mongoose.disconnect();
}

seed().catch(console.error);
