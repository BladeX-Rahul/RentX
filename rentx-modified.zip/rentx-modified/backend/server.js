require("dotenv").config();
const express  = require("express");
const cors     = require("cors");
const mongoose = require("mongoose");

const authRoutes    = require("./routes/auth");
const carRoutes     = require("./routes/cars");
const bookingRoutes = require("./routes/bookings");
const adminRoutes   = require("./routes/admin");

const app  = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({ origin: process.env.FRONTEND_URL || "http://localhost:3000", credentials: true }));
app.use(express.json());

// Routes
app.use("/api/auth",     authRoutes);
app.use("/api/cars",     carRoutes);
app.use("/api/bookings", bookingRoutes);
app.use("/api/admin",    adminRoutes);

// Health
app.get("/health", (_, res) => res.json({ status: "ok", service: "RentX API" }));

// 404
app.use((_, res) => res.status(404).json({ message: "Route not found." }));

// Error handler
app.use((err, _, res, __) => {
  console.error(err);
  res.status(500).json({ message: "Internal server error." });
});

// Connect DB then start
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✅ MongoDB connected");
    app.listen(PORT, () => console.log(`✅ RentX backend running on http://localhost:${PORT}`));
  })
  .catch(err => { console.error("MongoDB connection error:", err); process.exit(1); });
