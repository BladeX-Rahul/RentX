const express    = require("express");
const router     = express.Router();
const User       = require("../models/User");
const Car        = require("../models/Car");
const Booking    = require("../models/Booking");
const Subscriber = require("../models/Subscriber");
const { protect, adminOnly } = require("../middleware/auth");

// GET /api/admin/stats — dashboard stats
router.get("/stats", protect, adminOnly, async (req, res) => {
  try {
    const [totalCars, totalUsers, totalBookings, subscribers, bookings] = await Promise.all([
      Car.countDocuments(),
      User.countDocuments({ role: "user" }),
      Booking.countDocuments(),
      Subscriber.countDocuments(),
      Booking.find().select("totalPrice status"),
    ]);
    const revenue = bookings
      .filter(b => b.status !== "cancelled")
      .reduce((sum, b) => sum + b.totalPrice, 0);
    const pending   = bookings.filter(b => b.status === "pending").length;
    const confirmed = bookings.filter(b => b.status === "confirmed").length;
    res.json({ totalCars, totalUsers, totalBookings, subscribers, revenue, pending, confirmed });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/admin/users — all users
router.get("/users", protect, adminOnly, async (req, res) => {
  try {
    const users = await User.find().select("-password").sort({ createdAt: -1 });
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/admin/users/:id/toggle — activate/deactivate user
router.put("/users/:id/toggle", protect, adminOnly, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: "User not found." });
    user.isActive = !user.isActive;
    await user.save();
    res.json({ message: `User ${user.isActive ? "activated" : "deactivated"}.`, isActive: user.isActive });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/admin/subscribers
router.get("/subscribers", protect, adminOnly, async (req, res) => {
  try {
    const subs = await Subscriber.find().sort({ createdAt: -1 });
    res.json(subs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/admin/newsletter/subscribe — public
router.post("/newsletter/subscribe", async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ message: "Email is required." });
  try {
    const exists = await Subscriber.findOne({ email });
    if (exists) return res.status(400).json({ message: "Already subscribed!" });
    await Subscriber.create({ email });
    res.status(201).json({ message: "Subscribed successfully!" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
