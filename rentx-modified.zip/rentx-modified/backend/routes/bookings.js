const express  = require("express");
const router   = express.Router();
const Booking  = require("../models/Booking");
const Car      = require("../models/Car");
const { protect, adminOnly } = require("../middleware/auth");

// POST /api/bookings — create booking (logged in user)
router.post("/", protect, async (req, res) => {
  try {
    const { carId, startDate, endDate, pickupLocation, dropLocation } = req.body;
    if (!carId || !startDate || !endDate)
      return res.status(400).json({ message: "Car, start date and end date are required." });

    const car = await Car.findById(carId);
    if (!car) return res.status(404).json({ message: "Car not found." });
    if (!car.isAvailable) return res.status(400).json({ message: "Car is not available." });

    const start = new Date(startDate);
    const end   = new Date(endDate);
    if (end <= start) return res.status(400).json({ message: "End date must be after start date." });

    // Check for conflicting bookings
    const conflict = await Booking.findOne({
      car: carId,
      status: { $in: ["pending", "confirmed"] },
      $or: [{ startDate: { $lt: end }, endDate: { $gt: start } }],
    });
    if (conflict) return res.status(400).json({ message: "Car is already booked for these dates." });

    const totalDays  = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    const totalPrice = totalDays * car.pricePerDay;

    // Auto-confirm if car is available; otherwise stays pending for admin review
    const autoStatus = car.isAvailable ? "confirmed" : "pending";

    const booking = await Booking.create({
      user: req.user._id, car: carId, startDate: start, endDate: end,
      totalDays, totalPrice, pickupLocation, dropLocation,
      status: autoStatus,
      autoConfirmed: autoStatus === "confirmed",
    });
    await booking.populate("car");
    res.status(201).json(booking);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/bookings/my — user's own bookings
router.get("/my", protect, async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.user._id })
      .populate("car")
      .sort({ createdAt: -1 });
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/bookings — all bookings (admin)
router.get("/", protect, adminOnly, async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate("user", "name email phone")
      .populate("car", "name brand pricePerDay image")
      .sort({ createdAt: -1 });
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/bookings/:id/status — admin update status
router.put("/:id/status", protect, adminOnly, async (req, res) => {
  try {
    const { status } = req.body;
    const booking = await Booking.findByIdAndUpdate(
      req.params.id, { status }, { new: true }
    ).populate("user", "name email").populate("car", "name brand");
    if (!booking) return res.status(404).json({ message: "Booking not found." });
    res.json(booking);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/bookings/:id/cancel — user cancel own booking
router.put("/:id/cancel", protect, async (req, res) => {
  try {
    const booking = await Booking.findOne({ _id: req.params.id, user: req.user._id });
    if (!booking) return res.status(404).json({ message: "Booking not found." });
    if (booking.status === "cancelled") return res.status(400).json({ message: "Already cancelled." });
    booking.status = "cancelled";
    await booking.save();
    res.json(booking);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
