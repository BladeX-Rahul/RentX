const express  = require("express");
const router   = express.Router();
const Car      = require("../models/Car");
const { protect, adminOnly } = require("../middleware/auth");

// GET /api/cars — public, with filters
router.get("/", async (req, res) => {
  try {
    const { category, fuel, transmission, minPrice, maxPrice, available, search } = req.query;
    const filter = {};
    if (category)     filter.category     = category;
    if (fuel)         filter.fuelType     = fuel;
    if (transmission) filter.transmission = transmission;
    if (available === "true") filter.isAvailable = true;
    if (minPrice || maxPrice) {
      filter.pricePerDay = {};
      if (minPrice) filter.pricePerDay.$gte = Number(minPrice);
      if (maxPrice) filter.pricePerDay.$lte = Number(maxPrice);
    }
    if (search) {
      filter.$or = [
        { name:  { $regex: search, $options: "i" } },
        { brand: { $regex: search, $options: "i" } },
      ];
    }
    const cars = await Car.find(filter).sort({ createdAt: -1 });
    res.json(cars);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/cars/:id — public
router.get("/:id", async (req, res) => {
  try {
    const car = await Car.findById(req.params.id);
    if (!car) return res.status(404).json({ message: "Car not found." });
    res.json(car);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/cars — admin only
router.post("/", protect, adminOnly, async (req, res) => {
  try {
    const car = await Car.create(req.body);
    res.status(201).json(car);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT /api/cars/:id — admin only
router.put("/:id", protect, adminOnly, async (req, res) => {
  try {
    const car = await Car.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!car) return res.status(404).json({ message: "Car not found." });
    res.json(car);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE /api/cars/:id — admin only
router.delete("/:id", protect, adminOnly, async (req, res) => {
  try {
    const car = await Car.findByIdAndDelete(req.params.id);
    if (!car) return res.status(404).json({ message: "Car not found." });
    res.json({ message: "Car deleted." });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
