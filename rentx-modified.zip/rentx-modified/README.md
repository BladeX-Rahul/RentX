# RentX — Vehicle Rental Booking App

> Full-stack MERN application for vehicle rental booking with user and admin roles.

---

## Project Structure

```
rentx/
├── backend/     ← Node.js + Express + MongoDB
└── frontend/    ← React SPA
```

---

## Prerequisites

Make sure you have these installed:
- **Node.js** (v16+)
- **MongoDB** (running locally on port 27017)

To start MongoDB locally on Windows:
```
net start MongoDB
```
Or just open the **MongoDB Compass** app — it starts the service automatically.

---

## Backend Setup

```bash
# 1. Go into backend folder
cd rentx/backend

# 2. Install dependencies
npm install

# 3. Create .env file
copy .env.example .env     ← Windows
# cp .env.example .env     ← Mac/Linux

# 4. Open .env — default values are fine for local MongoDB, no changes needed

# 5. Seed the database (demo cars + admin account)
node seed.js

# 6. Start the backend
npm run dev
```

You should see:
```
✅ MongoDB connected
✅ RentX backend running on http://localhost:5000
```

---

## Frontend Setup

Open a **second terminal**:

```bash
# 1. Go into frontend folder
cd rentx/frontend

# 2. Install dependencies
npm install

# 3. Create .env file
copy .env.example .env     ← Windows
# cp .env.example .env     ← Mac/Linux

# 4. Start React
npm start
```

Opens automatically at **http://localhost:3000**

---

## Demo Credentials (after running seed.js)

| Role  | Email              | Password  |
|-------|--------------------|-----------|
| Admin | admin@rentx.com    | admin123  |
| User  | Register yourself  | —         |

---

## Pages & Features

### User Side
| Page           | Route            | Description                          |
|----------------|------------------|--------------------------------------|
| Home           | `/`              | Hero, featured cars, categories      |
| Browse Cars    | `/cars`          | Filter by category, fuel, price      |
| Car Detail     | `/cars/:id`      | Full details + booking form          |
| My Bookings    | `/my-bookings`   | View and cancel bookings             |
| Profile        | `/profile`       | Edit name, phone, password           |
| Login          | `/login`         | Sign in                              |
| Register       | `/register`      | Create account                       |

### Admin Side
| Page              | Route              | Description                     |
|-------------------|--------------------|---------------------------------|
| Dashboard         | `/admin`           | Stats overview                  |
| Manage Cars       | `/admin/cars`      | Add, edit, delete cars          |
| Manage Bookings   | `/admin/bookings`  | Confirm, complete, cancel       |
| Manage Users      | `/admin/users`     | Activate/deactivate users       |

---

## Tech Stack

| Layer    | Technology                    |
|----------|-------------------------------|
| Frontend | React 18, React Router v6     |
| Styling  | Custom CSS with CSS Variables |
| Backend  | Node.js, Express.js           |
| Database | MongoDB with Mongoose         |
| Auth     | JWT (jsonwebtoken + bcryptjs) |

---

## API Endpoints

### Auth
- `POST /api/auth/register` — Register
- `POST /api/auth/login`    — Login
- `GET  /api/auth/me`       — Get current user
- `PUT  /api/auth/profile`  — Update profile

### Cars
- `GET    /api/cars`       — List all (with filters)
- `GET    /api/cars/:id`   — Single car
- `POST   /api/cars`       — Add car (admin)
- `PUT    /api/cars/:id`   — Update car (admin)
- `DELETE /api/cars/:id`   — Delete car (admin)

### Bookings
- `POST /api/bookings`            — Create booking
- `GET  /api/bookings/my`         — My bookings
- `GET  /api/bookings`            — All bookings (admin)
- `PUT  /api/bookings/:id/status` — Update status (admin)
- `PUT  /api/bookings/:id/cancel` — Cancel (user)

### Admin
- `GET  /api/admin/stats`                    — Dashboard stats
- `GET  /api/admin/users`                    — All users
- `PUT  /api/admin/users/:id/toggle`         — Toggle user active
- `POST /api/admin/newsletter/subscribe`     — Subscribe to newsletter
- `GET  /api/admin/subscribers`              — All subscribers (admin)

---

## Running Both Together

```
Terminal 1 (backend)      Terminal 2 (frontend)
─────────────────────     ─────────────────────
cd rentx/backend          cd rentx/frontend
npm run dev               npm start
:5000                     :3000
```
